package com.airline.service;

public class FlightService {
    public boolean isSeatAvailable(String flightId) {
        // Only FL123 is full
        return !"FL123".equals(flightId);
    }
}

