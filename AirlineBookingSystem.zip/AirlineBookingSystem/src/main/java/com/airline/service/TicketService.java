package com.airline.service;

public class TicketService {
    private FlightService flightService;

    public void setFlightService(FlightService flightService) {
        this.flightService = flightService;
    }

    public void confirmBooking(String flightId, String userId) {
        if (flightService.isSeatAvailable(flightId)) {
            System.out.println("Booking confirmed for " + userId + " on " + flightId);
        } else {
            System.out.println("Flight " + flightId + " is full");
        }
    }
}

