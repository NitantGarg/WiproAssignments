DROP DATABASE ecommerce_appdb;
CREATE DATABASE ecommerce_appdb;