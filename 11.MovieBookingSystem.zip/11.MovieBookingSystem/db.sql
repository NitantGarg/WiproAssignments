CREATE DATABASE movie_db;

USE movie_db;

SHOW TABLES;

SELECT * FROM movie;
SELECT * FROM theater;
SELECT * FROM customer;
SELECT * FROM booking;
